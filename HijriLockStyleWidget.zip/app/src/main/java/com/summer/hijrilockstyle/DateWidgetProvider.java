package com.summer.hijrilockstyle;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public class DateWidgetProvider extends AppWidgetProvider {

    private static final String[] HIJRI_MONTHS = {
        "Muharram", "Safar", "Rabi al-Awwal", "Rabi al-Thani",
        "Jumada al-Awwal", "Jumada al-Thani", "Rajab", "Sha'ban",
        "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah"
    };

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        updateAll(context, manager, ids);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        updateAll(context, manager, manager.getAppWidgetIds(
                new android.content.ComponentName(context, DateWidgetProvider.class)));
    }

    private void updateAll(Context context, AppWidgetManager manager, int[] ids) {
        Calendar now = Calendar.getInstance();
        Locale locale = Locale.ENGLISH;

        SimpleDateFormat time = new SimpleDateFormat("HH:mm", locale);
        SimpleDateFormat date = new SimpleDateFormat("EEE d MMMM", locale);

        String[] hijri = toHijri(
                now.get(Calendar.YEAR),
                now.get(Calendar.MONTH) + 1,
                now.get(Calendar.DAY_OF_MONTH));

        for (int id : ids) {
            RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.date_widget);
            v.setTextViewText(R.id.time, time.format(now.getTime()));
            v.setTextViewText(R.id.gregorian, date.format(now.getTime()));
            v.setTextViewText(R.id.hijri, "(" + hijri[0] + " " + hijri[1] + ")");
            manager.updateAppWidget(id, v);
        }
    }

    // Tabular/civil Islamic calendar conversion.
    // It matches the common arithmetic Hijri calendar; a one-day adjustment
    // can be added later if the user wants to match a specific local moon-sighting calendar.
    private static String[] toHijri(int gy, int gm, int gd) {
        int jd = gregorianToJd(gy, gm, gd);
        int l = jd - 1948440 + 10632;
        int n = (l - 1) / 10631;
        l = l - 10631 * n + 354;
        int j = ((10985 - l) / 5316) * ((50 * l) / 17719)
              + (l / 5670) * ((43 * l) / 15238);
        l = l - ((30 - j) / 15) * ((17719 * j) / 50)
              - (j / 16) * ((15238 * j) / 43) + 29;
        int month = (24 * l) / 709;
        int day = l - (709 * month) / 24;
        int year = 30 * n + j - 30;
        return new String[]{HIJRI_MONTHS[month - 1], String.valueOf(day)};
    }

    private static int gregorianToJd(int y, int m, int d) {
        int a = (14 - m) / 12;
        int yy = y + 4800 - a;
        int mm = m + 12 * a - 3;
        return d + (153 * mm + 2) / 5 + 365 * yy + yy / 4
                - yy / 100 + yy / 400 - 32045;
    }
}
